﻿using System;
using System.Collections.Generic;
using System.Text;

public class Point : GameObject
{
    Random rand;

    int Xsize;
    int Ysize;

    Map map;

    Score score = new Score();
    public void Init(ref Map map)
    {
        Symbol = 'O';

        rand = new Random();

        Xsize = map.Xsize;
        Ysize = map.Ysize;

        this.map = map;
        UpdatePos();

    }

    public void Update(Player player, ref Enemy enemy)
    {
        CheckPlayer(player , ref enemy);
    }

    public void Render()
    {
        Console.SetCursorPosition(Position.X, Position.Y);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write(Symbol);
        Console.ResetColor();

        score.Render(ref map);
    }

    void UpdatePos()
    {
        while(true)
        {
            rand.Next(Xsize);
            int temp = rand.Next(Xsize);
            Vector nextPos = new Vector(temp, rand.Next(Ysize));
            Position = nextPos;
            if (map.CheckWall(Position) == false)
                break;
        }
    }

    public void CheckPlayer(Player player, ref Enemy enemy)
    {
        if (Position == player.Position)
        {
            UpdatePos();
            score.PlusScore();
            enemy.MoveFaster();
        }

    }
}