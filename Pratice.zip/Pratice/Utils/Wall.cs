﻿public class Wall : GameObject
{
    public Wall(Vector position)
    {
        Symbol = '█';
        Position = position;
    }
}